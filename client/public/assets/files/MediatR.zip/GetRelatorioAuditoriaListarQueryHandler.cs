﻿using Dapper;
using MediatR;
using Microsoft.Extensions.Logging;
using svv.application.core.Handlers.Models.Auditoria;
using svv.infrastructure.common.Exceptions;
using svv.infrastructure.common.Resources.Builders;
using svv.infrastructure.data.AuditContext.Interfaces;
using Z.BulkOperations;

namespace svv.application.core.Handlers.Queries.Auditoria;

public class GetRelatorioAuditoriaListarQueryHandler : IRequestHandler<GetRelatorioAuditoriaListarQuery, List<GetRelatorioAuditoriaListarQueryCommandResponseDto>>
{
    private readonly ILogger<IAuditDbConnection> _logger;
    private readonly IAuditDbConnection _auditDbConnection;
    private string _DataInicial = "Data inicial";
    private string _DataFinal = "Data final";

    public GetRelatorioAuditoriaListarQueryHandler(IAuditDbConnection dbConnection, ILogger<IAuditDbConnection> logger)
    {
        _auditDbConnection = dbConnection ?? throw new ArgumentNullException(nameof(dbConnection));
        _logger = logger;
    }

    public async Task<List<GetRelatorioAuditoriaListarQueryCommandResponseDto>> Handle(GetRelatorioAuditoriaListarQuery request, CancellationToken cancellationToken)
    {
        var filtro = string.Empty;

        if (!string.IsNullOrEmpty(request.Usuario))
        {
            filtro += @" AND CreatedBy = @Usuario ";
        }

        DateTime? dataFinal = null;

        if (request.DataInicial > request.DataFinal)
            throw new BusinessException(ExceptionMessageType.Business_InvalidDateValue, _DataInicial, _DataFinal );

        if (request.DataInicial.HasValue && request.DataFinal.HasValue)
        {
            dataFinal = request.DataFinal.Value.AddDays(1).Date.AddSeconds(-1);
            filtro += @" AND CreatedOn BETWEEN @DataInicial AND @DataFinal ";
        }

        if (request.EcvId.HasValue && request.EcvId.Value != Guid.Empty)
        {
            filtro += " AND EcvId = @EcvId ";
        }

        if (!string.IsNullOrEmpty(request.VistoriaId))
        {
            filtro += " AND VistoriaId = @VistoriaId ";
        }

        var query = @"SELECT
                    Id,
                    CommandName as NomeComando,
                    CommandBody as CorpoComando,
                    CreatedBy as CriadoPor,
                    DATE_FORMAT(CONVERT_TZ(CreatedOn, '+00:00', '-03:00'), '%d/%m/%Y %H:%i') AS CriadoEm
                FROM
                    auditoria
                WHERE
                    1=1 " + filtro + @" ORDER BY CreatedOn Desc";

        var relatorio = await _auditDbConnection.Connection.QueryAsync<GetRelatorioAuditoriaListarQueryCommandResponseDto>(query,
            new { request.EcvId, request.VistoriaId, request.Usuario, request.DataInicial, DataFinal = dataFinal }
        );

        return relatorio.AsList();
    }
}