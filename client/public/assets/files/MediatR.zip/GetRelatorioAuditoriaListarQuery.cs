﻿using MediatR;
using svv.application.core.Handlers.Models.Auditoria;

namespace svv.application.core.Handlers.Queries.Auditoria;

public class GetRelatorioAuditoriaListarQuery : IRequest<List<GetRelatorioAuditoriaListarQueryCommandResponseDto>>
{
    public Guid? EcvId { get; private set; }
    public string? VistoriaId { get; private set; }
    public string? Usuario { get; private set; }
    public DateTime? DataInicial { get; private set; }
    public DateTime? DataFinal { get; private set; }

    public GetRelatorioAuditoriaListarQuery(Guid? ecvId, string? vistoriaId, string? usuario, DateTime? dataInicial, DateTime? dataFinal)
    {
        EcvId = ecvId;
        VistoriaId= vistoriaId;
        Usuario = usuario;
        DataInicial = dataInicial;
        DataFinal = dataFinal;
    }
}
