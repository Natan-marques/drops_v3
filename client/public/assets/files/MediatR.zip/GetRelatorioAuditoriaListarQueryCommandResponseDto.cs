﻿namespace svv.application.core.Handlers.Models.Auditoria;

public class GetRelatorioAuditoriaListarQueryCommandResponseDto
{
    public Guid Id { get; set; }
    public string NomeComando { get; set; }
    public string CorpoComando { get; set; }
    public string CriadoPor { get; set; }
    public string CriadoEm { get; set; }
}
