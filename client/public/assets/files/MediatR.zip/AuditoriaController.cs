﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using svv.service.api.Attributes;
using svv.infrastructure.common.Jwt;
using svv.application.core.Handlers.Models.Auditoria;
using svv.application.core.Handlers.Queries.Auditoria;

namespace svv.service.api.Controllers
{
    /// <summary>
    /// Endpoints relacionados ao agregado Auditoria.
    /// </summary>
    [Route("api/[controller]")]
    [Autorizacao(Constants.JwtRoleName.Administrador, Constants.JwtRoleName.AuditorDetran)]
    public class AuditoriaController : ApiController
    {
        private readonly IMediator _mediator;

        public AuditoriaController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Consulta do relatório de logs de auditoria.
        /// </summary>
        /// <response code="200">Sucesso, retorna o relatório de logs de auditoria.</response>
        /// <response code="500">Se a requisição contém campos inválidos ou regras de negócio incorretas.</response>        
        /// <response code="401">Não autorizado, requer os papéis de Administrador, AuditorDetran ou AuditorSistema ou token inválido.</response> 
        [HttpGet("relatorio")]
        [ProducesResponseType(typeof(List<GetRelatorioAuditoriaListarQueryCommandResponseDto>), 200)]
        public async Task<IActionResult> GetRelatorio(
            Guid? ecvId,
            string? vistoriaId,
            string? usuario,
            DateTime? dataInicial,
            DateTime? dataFinal,
            CancellationToken cancellationToken
        )
        {
            var relatorio = await _mediator.Send(new GetRelatorioAuditoriaListarQuery(
                ecvId,
                vistoriaId,
                usuario,
                dataInicial,
                dataFinal),
                cancellationToken
            );

            return Ok(relatorio);
        }
    }
}
